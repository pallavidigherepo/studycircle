<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

class ImportController extends Controller
{
    public function store(Request $request)
    {
        $file = $request->file('import_file')->store('import');
        $modelName = $request->modelName;
        $importClass = "App\\Imports\\".$modelName."Import";

        $import = new $importClass;
        try {
            Excel::import($import, $file);
            $response = [
                'success' => true,
                'message' => 'All the '.$modelName.'(s) are successfully imported.',
                'failures' => null,
            ];
        } catch (\Maatwebsite\Excel\Validators\ValidationException $e) {
             $failures = $e->failures();
             $response = [
                'success' => false,
                'message' => $modelName.'(s) are not imported.',
                'failures' => $failures,
             ];
        }
        return response()->json($response);
    }
}
