import { ref } from 'vue'

const copySource = ref('')

export { copySource }
