export default {
    coursesTypes(state) {
        return state.coursesTypes;
    },

    coursesType(state) {
        return state.coursesType;
    },

    courseTypeList(state) {
        return state.courseTypeList;
    },

    datatable(state) {
        return state.datatable;
    },
    
    meta(state) {
        return state.pagination;
    }
}