export default {
    languages(state) {
        return state.languages;
    }
}