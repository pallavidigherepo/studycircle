export default {
    LANGUAGES(state, payload) {
        state.languages = payload;
    }
}