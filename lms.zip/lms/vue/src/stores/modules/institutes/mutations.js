export default{
    FETCH_INSTITUTES(state, payload) {
        state.institutes = payload;
    },
};