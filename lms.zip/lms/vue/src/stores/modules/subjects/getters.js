export default {
    subjects(state) {
        return state.subjects;
    },
    languages(state) {
        return state.languages;
    },

    subject(state) {
        return state.subject;
    },
    courses(state) {
        return state.courses;
    },
    

    datatable(state) {
        return state.datatable;
    },
    
    meta(state) {
        return state.pagination;
    }
}