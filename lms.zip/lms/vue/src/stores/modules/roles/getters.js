export default {
    roles(state) {
        return state.roles;
    },

    role(state) {
        return state.role;
    },
    
    datatable(state) {
        return state.datatable;
    },
    meta(state) {
        return state.pagination;
    }
}