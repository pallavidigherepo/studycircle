export default {
    questions(state) {
        return state.questions;
    },
    languages(state) {
        return state.languages;
    },

    question(state) {
        return state.question;
    },
};