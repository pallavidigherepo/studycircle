export default {
    chapters(state) {
        return state.chapters;
    },
    languages(state) {
        return state.languages;
    },
    subjects(state) {
        return state.subjects;
    },
    chapter(state) {
        return state.chapter;
    }
}