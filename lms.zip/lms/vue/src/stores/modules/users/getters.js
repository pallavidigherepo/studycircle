export default {
    users(state) {
        return state.users;
    },

    user(state) {
        return state.user;
    },
    
    datatable(state) {
        return state.datatable;
    },
    meta(state) {
        return state.pagination;
    },
    
    roleList(state) {
        return state.roleList;
    }

}