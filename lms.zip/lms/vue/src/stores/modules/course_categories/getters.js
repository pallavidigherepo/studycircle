export default {
    courseCategories(state) {
        return state.courseCategories;
    },

    courseCategory(state) {
        return state.courseCategory;
    }
}